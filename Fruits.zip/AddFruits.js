import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, TouchableOpacity, Image } from 'react-native';

const AddFruitsScreen = () => {
  const [productName, setProductName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [calories, setCalories] = useState('');
  // You will need to manage the selected icon state

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Add Fruits</Text>
      <Text style={styles.label}>Product Name</Text>
      <TextInput 
        style={styles.input}
        placeholder="Please type the product name"
        onChangeText={setProductName}
        value={productName}
      />
      <Text style={styles.label}>Quantity</Text>
      <TextInput 
        style={styles.input}
        placeholder="Please type the quantity"
        onChangeText={setQuantity}
        value={quantity}
        keyboardType="numeric"
      />
      <Text style={styles.label}>Expired date</Text>
      <TextInput 
        style={styles.input}
        placeholder="Please type the expired date"
        onChangeText={setExpiryDate}
        value={expiryDate}
      />
      <Text style={styles.label}>Calories</Text>
      <TextInput 
        style={styles.input}
        placeholder="Please type the calories"
        onChangeText={setCalories}
        value={calories}
        keyboardType="numeric"
      />
      <Text style={styles.iconChoiceLabel}>Choose Icon</Text>
      <View style={styles.iconContainer}>
        {/* Icons touchable components will go here */}
        <TouchableOpacity style={styles.iconWrapper}>
          <Image source={require('banana.png')} style={styles.icon} />
          <Text>Banana</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.iconWrapper}>
          <Image source={require('cola_2804426.png')} style={styles.icon} />
          <Text>Soda</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.iconWrapper}>
          <Image source={require('milk_5125422.png')} style={styles.icon} />
          <Text>Milk</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.iconWrapper}>
          <Image source={require('fruit.png')} style={styles.icon} />
          <Text>Others</Text>
        </TouchableOpacity>
        {/* Repeat for other icons */}
      </View>
      <TouchableOpacity style={styles.addButton}>
        <Text style={styles.addButtonText}>Add Fruits</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 24,
    fontFamily: 'Signika',
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
    fontFamily: 'Signika',
  },
  iconChoiceLabel: {
    fontSize: 18,
    fontFamily: 'Signika',
    marginBottom: 10,
  },
  iconContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
    alignItems: 'center'
  },
  iconWrapper: {
    alignItems: 'center', 
    marginHorizontal: 10, 
  },
  icon: {
    width: 50,
    height: 50,
  },
  addButton: {
    backgroundColor: '#FFAEB7',
    borderRadius: 20,
    paddingVertical: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addButtonText: {
    color: '#fff',
    fontSize: 18,
    fontFamily: 'Signika',
    fontWeight: 'bold',
  },
  label: {
    fontSize: 16,
    fontFamily: 'Signika',
    color: '#000',
    marginBottom: 5,
  },
});

export default AddFruitsScreen;