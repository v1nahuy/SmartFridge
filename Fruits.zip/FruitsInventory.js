import React from 'react';
import { StyleSheet, View, Text, TextInput, FlatList, Image, TouchableOpacity } from 'react-native';

const drinksData = [
  { id: '1', name: 'Banana', kcal: '250 Kcal', quantity: 3, image: require('banana.png') },
  { id: '2', name: 'Apple', kcal: '250 Kcal', quantity: 4, image: require('fruit.png') },
  { id: '3', name: 'Orange', kcal: '800 Kcal', quantity: 2, image: require('fruit.png') },
];

const App = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Drinks Inventory</Text>
      <TextInput style={styles.searchInput} placeholder="Search" />
      <FlatList
        data={drinksData}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <Image source={item.image} style={styles.itemImage} />
            <View style={styles.itemInfo}>
              <Text style={styles.itemKcal}>{item.kcal}</Text>
              <Text style={styles.itemName}>{item.name}</Text>
            </View>
            <Text style={styles.itemQuantity}>{item.quantity}</Text>
          </View>
        )}
      />
      <TouchableOpacity style={styles.addButton}>
        <Text style={styles.addButtonText}>Add Drinks</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    fontFamily: 'Signika', 
  },
  header: {
    fontSize: 22,
    fontWeight: '550',
    textAlign: 'center',
    marginVertical: 20,
    fontFamily: 'Signika', 
  },
  searchInput: {
    height: 40,
    marginHorizontal: 20,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 20,
    paddingHorizontal: 15,
    fontFamily: 'Signika', 
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF8EE',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginHorizontal: 20,
    marginTop: 10,
  },
  itemImage: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  itemInfo: {
    flex: 1,
  },
  itemKcal: {
    fontSize: 16,
    color: '#6CB663',
    fontFamily: 'Signika', 
  },
  itemName: {
    fontSize: 18,
    fontWeight: '600',
    fontFamily: 'Signika', 
  },
  itemQuantity: {
    fontSize: 24,
    fontWeight: '600',
    fontFamily: 'Signika', 
  },
  addButton: {
    backgroundColor: '#FFAEB7',
    borderRadius: 20,
    paddingVertical: 25,
    paddingHorizontal: 80,
    alignSelf: 'center',
    marginTop: 20,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
    textAlign: 'center',
    fontFamily: 'Signika', 
  },
});

export default App;