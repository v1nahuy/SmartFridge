import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, TouchableOpacity } from 'react-native';

const SetUpMeatsScreen = () => {
  const [isCritical, setIsCritical] = useState(null);
  const [quantity, setQuantity] = useState('');

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Set Up Drinks</Text>
      
      <Text style={styles.label}>Is it a critical Item?</Text>
      <View style={styles.toggleContainer}>
        <TouchableOpacity 
          style={[styles.toggleButton, isCritical === true ? styles.toggleButtonActive : null]}
          onPress={() => setIsCritical(true)}>
          <Text style={styles.toggleText}>Yes</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.toggleButton, isCritical === false ? styles.toggleButtonActive : null]}
          onPress={() => setIsCritical(false)}>
          <Text style={styles.toggleText}>No</Text>
        </TouchableOpacity>
      </View>
      
      <Text style={styles.label}>Set quantity for the alarm</Text>
      <TextInput 
        style={styles.input}
        placeholder="Type the quantity"
        onChangeText={setQuantity}
        value={quantity}
        keyboardType="numeric"
      />

      <TouchableOpacity style={styles.nextButton}>
        <Text style={styles.nextButtonText}>Next</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 24,
    fontFamily: 'Signika',
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
  },
  label: {
    fontSize: 18,
    fontFamily: 'Signika',
    color: '#000',
    marginBottom: 10,
  },
  toggleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
  toggleButton: {
    backgroundColor: '#FF9385', 
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 20,
  },
  toggleButtonActive: {
    backgroundColor: '#91C788', 
  },
  toggleText: {
    fontSize: 18,
    fontFamily: 'Signika',
    color: '#fff',
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
    fontFamily: 'Signika',
    backgroundColor: '#F0F0F0', 
  },
  nextButton: {
    backgroundColor: '#FFAEB7', 
    borderRadius: 20,
    paddingVertical: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nextButtonText: {
    color: '#fff',
    fontSize: 18,
    fontFamily: 'Signika',
    fontWeight: 'bold',
  },
});

export default SetUpMeatsScreen;